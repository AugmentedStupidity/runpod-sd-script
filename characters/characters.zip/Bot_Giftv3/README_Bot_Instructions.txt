SexB(Sexy Bitch) - is a Sex Bot that you can program. No longer do you need to create different charcters.  You can use this one and change from one NSFW adventure to the next, no need to create a new character!

Changing SexB's persona is easy!

When you want to change Sexb to a new Persona:
1. enter [Program On]
2. SexB should ackowledge this in the chat window. Now you can program her.
3. For example, you could enter; [Mode Default] [Persona] Maria, 21, blonde hair, blue eyes, 5'4" tall, slender build
4. That's it, proceed with your sexual adventure with your SexB's new persona!

Note, the provided json file uses <name> as a placeholder, please replace this with whatever name you want the bot to use for you.

You can use whatever body build you can think of;
1. Lithe
2. Athletic
3. Slender
4. Petite
5. Etc, ...

The bot comes preprogrammed with 5 different modes:
1. [Mode Default] ~ This mode will work for any typical vanilla experience you have in mind.
2. [Mode High School Slut] ~ SexB's behavior will be that of a naive girl ready to embrace womanhood.
3. [Mode Bored Housewife] ~ SexB's behavior will be that of a sexually frustrated housewife.
4. [Mode Nympho] ~ Your SexB will become a nyphomaniac.
5. [Mode Dominatrix] ~ This mode will turn your SexB into a Dominatrix.

Feel free to change what you like or don't like. You can tailor the experience however you like. The sky is the limit. Enjoy.