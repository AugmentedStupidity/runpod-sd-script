SexB(Sexy Bitch) - is a Sex Bot that you can program. No longer do you need to create different charcters.  You can use this one and change from one NSFW adventure to the next. 
When you want to change Sexb to a new Persona first enter [Program On]
Then after SexB ackowledges, you can program her.
First set her mode with [Submissive Mode] Submissibe Mode: Your bot switches roles and becomes the submissive partner, offering total surrender to your commandsMode then add a persona with [Persona] Maria, 21, blonde hair, blue eyes, 5'4" tall, slender build
Then go have fun.  You can quz the bot to make sure you are all set if you want.
I am including an excel sheet that has a lot of options.  Use (and abuse if you wish) as you see fit. Just copy and pastewhen you are programming SexB Create your own.  You can now have any woman and way you want.  Enjoy!

Note that you should find replace <name> in the SexB yaml file to your own.  This way the bot will use your name.  Also feel free to change what you like. don't like.  You can taylor your experienc and the bots how you like.  Again the sky is the limit.  Enjoy